using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace FeriadosChileNet5.Models
{
    public class FeriadosResponse
    {
        [JsonPropertyName("data")]
        public List<Feriado> Data { get; set; } = new List<Feriado>();
    }
}
