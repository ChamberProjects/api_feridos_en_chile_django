using System;
using System.Text.Json.Serialization;

namespace FeriadosChileNet5.Models
{
    public class Feriado
    {
        [JsonPropertyName("date")]
        public DateTime Date { get; set; }

        [JsonPropertyName("title")]
        public string Title { get; set; } = string.Empty;

        [JsonPropertyName("type")]
        public string Type { get; set; } = string.Empty;

        [JsonPropertyName("inalienable")]
        public bool Inalienable { get; set; }

        [JsonPropertyName("extra")]
        public string Extra { get; set; } = string.Empty;
    }
}
